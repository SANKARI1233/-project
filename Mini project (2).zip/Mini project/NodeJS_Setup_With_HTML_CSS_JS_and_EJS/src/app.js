// Import
const express = require('express');
const mysql = require('mysql');
const route = require('../routes/route'); // Adjust the path to your routes file
const app = express();
const path = require('path');
const partials = require('express-partials');
const { error } = require('console');

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Set Views directory
app.set('views', path.join(__dirname, '.')); // Views directory is current directory

// Use express-partials
app.use(partials());

// Static Files
app.use(express.static(path.join(__dirname, '../../public')));
app.use('/css', express.static(path.join(__dirname, '../../public/css')));
app.use('/js', express.static(path.join(__dirname, '../../public/js')));
app.use('/img', express.static(path.join(__dirname, '../../public/img')));

// Use the routes
app.use('/', route);

// Listen on port 5502
const port = 5502; // Change to a different port number
app.listen(port, function () {
  console.log(`Bubble node app running on port ${port}`);
});

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "nodejs-login",
});

db.connect((error) => {
  if (error) {
    console.log(error)
  } else {
    console.log("MYSQL CONNECTED ...")
  }
});
