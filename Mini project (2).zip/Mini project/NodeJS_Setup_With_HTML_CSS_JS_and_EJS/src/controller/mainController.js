
  
  const about = async function (req, res) {
    res.render('about', { text: 'About Page' });
  };
  
  const faqs = async function (req, res) {
    res.render('faqs', { text: 'FAQs Page' });
  };
  
  const forum = async function (req, res) {
    res.render('forum', { text: 'Forum Page' });
  };
  
  const blog1 = async function (req, res) {
    res.render('blog1', { text: 'Blog 1 Page' });
  };
  
  const blog2 = async function (req, res) {
    res.render('blog2', { text: 'Blog 2 Page' });
  };
  
  const blog3 = async function (req, res) {
    res.render('blog3', { text: 'Blog 3 Page' });
  };
  
  const resources = async function (req, res) {
    res.render('resources', { text: 'Resources Page' });
  };
  
  const testimonial = async function (req, res) {
    res.render('testimonial', { text: 'Testimonial Page' });
  };
  
  const educational = async function (req, res) {
    res.render('educational', { text: 'Educational Page' });
  };
  
  const login = async function (req, res) {
    res.render('login', { text: 'Login Page' });
  };
  
  const signup = async function (req, res) {
    res.render('signup', { text: 'Signup Page' });
  };
  
  const MentalHealthTest = async function (req, res) {
    res.render('MentalHealthTest', { text: 'Mental Health Test Page' });
  };
  
  // Export all functions
  module.exports = {
   
    about,
    faqs,
    forum,
    blog1,
    blog2,
    blog3,
    resources,
    testimonial,
    educational,
    login,
    signup,
    MentalHealthTest,
  };
  