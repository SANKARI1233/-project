const express = require('express');
const router = express.Router();
const mainController = require('../controller/mainController'); // Correctly require the controller
const express = require('express');





// Define routes
router.get('/', mainController.index);
router.get('/about', mainController.about);
router.get('/faqs', mainController.faqs);
router.get('/forum', mainController.forum);
router.get('/blog1', mainController.blog1);
router.get('/blog2', mainController.blog2);
router.get('/blog3', mainController.blog3);
router.get('/resources', mainController.resources);
router.get('/testimonial', mainController.testimonial);
router.get('/educational', mainController.educational);
router.get('/login', mainController.login);
router.get('/signup', mainController.signup);
router.get('/MentalHealthTest', mainController.MentalHealthTest);

// Handle undefined routes
router.all('/*', function (req, res) {
  res.status(404).send({ status: false, message: 'The API you requested is not available' });
});

module.exports = router;
