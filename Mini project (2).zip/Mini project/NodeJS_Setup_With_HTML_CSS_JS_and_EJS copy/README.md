np![alt text](image.png)HTML And CSS setup with Node JS unsing EJS Engine

1. Clone Project
2. Run "npm install"
3. Run "nodemon"

Demo URL : https://node-js-setup-with-html-css-js-and-ejs.vercel.app/
